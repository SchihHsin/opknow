# Anonymous supplement / 匿名补充材料
The v0.3 application links 52 task-side records to 350 selected external-tool
call/return pairs. Read data/trace-v0.3/README.md for selection, scope and provenance.
The original numerical files and their manifest remain frozen.
The old worked A form and original protocol are v0.2 artifacts; the applied
v0.3 ledger provides the current evidence links.
- protocol-cn-en-v0.3.md: bilingual protocol
- data/trace-v0.3/: selected returns, task attempts, application ledger and hashes
- scripts/verify_trace_application.py: offline integrity and coverage checks
- scripts/build_paper_analysis.py: historical arithmetic
- figures/v0.3/: six bilingual design illustrations

Run both scripts with Python 3. These checks verify integrity and internal
consistency; they do not establish independent coding agreement or task success.
No new website experiments were run. Whole private conversations and reasoning
are excluded. Returned text is tool-delivered material, not raw HTTP.

中文：本包包含52任务侧记录、350条选取的工具调用—返回对及其关联。
历史数值保持冻结；新增材料的范围、来源和解释见 trace-v0.3/README.md。
检查脚本验证文件完整性和内部一致性，不代表独立编码或运行成功验证。
