# Supplement: Knowledge Availability for AI

This anonymous supplement accompanies the methodological paper. It contains an
archival case application, not new website measurements or execution trials.

- `data/`: 26 tasks / 52 frozen task-side records, source-provenance notes,
  historical scoring code, known corrections, and descriptive outputs.
- `protocol-cn-en.md`: the reusable protocol, in English and Chinese.
- `record-template.json`: a blank future recording form, not observed data.
- `scripts/build_paper_analysis.py`: portable offline arithmetic reproduction.

Run with Python 3, without external dependencies:

    python3 scripts/build_paper_analysis.py

The primary comparison excludes task G's ROCm/HIP migration analogy and contains
25 pairs. The original records are retained. H.cuda's vendor-blog ownership is
flagged in the audit view; A.cann's failure-count boundary remains unresolved.
Descriptive access profiles treat static and server-rendered returns alike.
Historical scores are provided for traceability, not as calibrated probabilities.

The English task summaries translate the retained Chinese questions. The process
log is preserved in its original language. A full original tool transcript and
verified deployment configuration are not part of this archive. No independent
human coding or hardware-execution validation is claimed.

## 中文说明

本补充材料保留26任务52单元，主比较排除G的ROCm/HIP迁移类比后为25对。
包含冻结数据、历史评分、来源说明、归类修订和未决计数、可复用协议及空白记录表。
脚本只做已有记录的离线计算，不重新联网检索。历史指数不是答案正确概率。
问题的英文摘要是编辑性翻译；过程日志保留原中文。材料不声称包含完整工具会话、
已核实部署配置、独立人工编码或硬件执行验证。
