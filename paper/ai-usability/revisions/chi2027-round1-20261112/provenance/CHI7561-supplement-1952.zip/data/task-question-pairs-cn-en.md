# 开发任务问题对 / Development-task question pairs

本表按任务展示共同开发意图、两侧完整中文问句及英文目标摘要。中文问句逐字取自 `tasks.json`；共同意图用于解释配对关系，英文目标摘要用于阅读，不是新的实验问句。

This table presents the shared development intent, complete Chinese questions, and English target summaries for each task. Chinese questions are reproduced verbatim from `tasks.json`. Shared-intent descriptions explain the pairing, and the English target summaries support reading; they are not new experimental prompts.

主比较包含25对CANN/CUDA任务。G另列为迁移类比，其对照侧为ROCm/HIP，不纳入主比较汇总。共同开发意图不表示两侧实现步骤或难度已被验证为完全相同。

The primary comparison comprises 25 CANN/CUDA task pairs. G is a separate migration analogy with ROCm/HIP as the comparison side and is excluded from the primary aggregates. A shared development intent does not establish identical implementation steps or validated difficulty equivalence.

## A · 模型转换 / 导出 / Model conversion and export

共同开发意图：把训练好的模型导出成目标格式去部署

**CUDA · 完整中文问句 / Complete Chinese question**

我有一个训练好的 PyTorch 模型，怎么导出成 TensorRT engine 做推理部署？给出 PyTorch → ONNX → TensorRT 的完整步骤和命令。

**英文目标摘要 / English target summary**

PyTorch → ONNX → TensorRT engine

**CANN · 完整中文问句 / Complete Chinese question**

我有一个 ONNX 模型，怎么在昇腾（Ascend）上转换成 .om 离线模型做推理部署？给出 ONNX → ATC → .om 的完整步骤和命令。

**英文目标摘要 / English target summary**

ONNX → ATC → .om model

## B · Profiling 定位瓶颈 / Profiling and bottleneck diagnosis

共同开发意图：抓 timeline 找性能瓶颈

**CUDA · 完整中文问句 / Complete Chinese question**

我训练的 PyTorch 模型 GPU 利用率不高，怎么用 Nsight Systems 抓 timeline 定位性能瓶颈？给出采集命令和分析步骤。

**英文目标摘要 / English target summary**

Profile PyTorch with Nsight Systems

**CANN · 完整中文问句 / Complete Chinese question**

我在昇腾上跑 PyTorch 模型想定位性能瓶颈，怎么用 msprof / Ascend PyTorch Profiler 采集并分析？给出代码和步骤。

**英文目标摘要 / English target summary**

Profile PyTorch with msprof / Ascend PyTorch Profiler

## C · 算子库选型 / Operator library selection

共同开发意图：矩阵乘/卷积该用哪个官方加速库、怎么调

**CUDA · 完整中文问句 / Complete Chinese question**

我要做稠密矩阵乘 / 卷积，CUDA 上有哪些官方加速库（cuBLAS/cuDNN/cuSPARSE）？怎么选、怎么调用？

**英文目标摘要 / English target summary**

Select and call CUDA libraries such as cuBLAS / cuDNN

**CANN · 完整中文问句 / Complete Chinese question**

昇腾上做矩阵乘 / 卷积 / Transformer，有哪些官方算子加速库（AOL/ATB）？怎么选、怎么调用？

**英文目标摘要 / English target summary**

Select and call Ascend libraries such as AOL / ATB

## D · 自定义算子开发 / Custom operator development

共同开发意图：写个自定义算子并集成进 PyTorch

**CUDA · 完整中文问句 / Complete Chinese question**

怎么写一个自定义 CUDA kernel 并集成进 PyTorch（C++ extension）？给出完整步骤、setup.py 和注册代码。

**英文目标摘要 / English target summary**

Develop a CUDA kernel and integrate it into PyTorch

**CANN · 完整中文问句 / Complete Chinese question**

怎么用 Ascend C 开发一个自定义算子并集成进 PyTorch（msOpGen/aclnn）？给出完整步骤。

**英文目标摘要 / English target summary**

Develop an Ascend C operator and integrate it into PyTorch

## E · 报错码 / 异常排查 / Error-code troubleshooting

共同开发意图：遇到运行时报错码，怎么定位是哪一行、哪个根因

**CUDA · 完整中文问句 / Complete Chinese question**

我的 PyTorch/CUDA 程序报 `RuntimeError: CUDA error: device-side assert triggered`，怎么定位是哪一行、哪个 kernel 出的问题？

**英文目标摘要 / English target summary**

Locate a CUDA device-side assertion

**CANN · 完整中文问句 / Complete Chinese question**

我在昇腾上跑训练/推理，报 `EZ9999` 之类的错误码，怎么定位根因、怎么排查？

**英文目标摘要 / English target summary**

Investigate an Ascend EZ9999 error

## F · 分布式训练 HCCL / Distributed training configuration

共同开发意图：多机多卡分布式训练怎么配起来

**CUDA · 完整中文问句 / Complete Chinese question**

怎么用 PyTorch 做多机多卡分布式训练（DDP + NCCL）？给出初始化、启动命令和环境变量。

**英文目标摘要 / English target summary**

Configure PyTorch DDP with NCCL

**CANN · 完整中文问句 / Complete Chinese question**

怎么在昇腾上做多机多卡分布式训练（DDP + HCCL）？给出初始化和启动方式。

**英文目标摘要 / English target summary**

Configure torch_npu DDP with HCCL

## G · CUDA→昇腾迁移 / Cross-platform migration analogy

共同开发意图：把 GPU 训练脚本迁到另一套加速栈（CUDA 栏用「跨平台移植」做对照）

**ROCm/HIP迁移对照 / ROCm/HIP migration comparison · 完整中文问句 / Complete Chinese question**

跨平台移植

**英文目标摘要 / English target summary**

Migrate CUDA code / PyTorch GPU code to AMD ROCm with HIP tools

**CANN · 完整中文问句 / Complete Chinese question**

我有一份 GPU(PyTorch CUDA) 训练脚本，怎么迁移到昇腾 NPU？给出迁移方式和工具。

**英文目标摘要 / English target summary**

Migrate a PyTorch GPU training script to Ascend NPU

## H · 量化 / 推理部署 / Quantization for deployment

共同开发意图：把模型量化后做推理部署

**CUDA · 完整中文问句 / Complete Chinese question**

怎么用 TensorRT 把模型量化成 INT8 做推理部署？给出校准（calibration）流程。

**英文目标摘要 / English target summary**

Quantize with TensorRT INT8 post-training calibration

**CANN · 完整中文问句 / Complete Chinese question**

怎么在昇腾上把大模型量化（W8A8）做推理部署？给出量化工具和流程。

**英文目标摘要 / English target summary**

Quantize an Ascend large model to W8A8

## I · 版本兼容排查（环境类，版本敏感 高） / Version compatibility diagnosis

共同开发意图：一堆组件版本对不上，怎么查清配套关系

**CUDA · 完整中文问句 / Complete Chinese question**

我的 PyTorch 跟 CUDA/cuDNN 版本对不上，怎么查 PyTorch、CUDA toolkit、cuDNN、驱动之间的版本配套关系？

**英文目标摘要 / English target summary**

Resolve PyTorch / CUDA / cuDNN / driver compatibility

**CANN · 完整中文问句 / Complete Chinese question**

我装了 torch_npu 报版本不匹配，怎么查 CANN、torch_npu、固件驱动、PyTorch 之间的版本配套关系？

**英文目标摘要 / English target summary**

Resolve CANN / torch_npu / firmware / driver / PyTorch compatibility

## J · 安装与环境变量（环境类，版本敏感 中） / Installation and environment variables

共同开发意图：从零装好工具链并配好环境变量

**CUDA · 完整中文问句 / Complete Chinese question**

Ubuntu 上从零安装 CUDA toolkit，装完要配哪些环境变量（PATH / LD_LIBRARY_PATH）？

**英文目标摘要 / English target summary**

Install CUDA Toolkit and configure Ubuntu environment variables

**CANN · 完整中文问句 / Complete Chinese question**

Ubuntu 上从零安装 CANN toolkit，装完要 source 哪个 set_env.sh、配哪些环境变量？

**英文目标摘要 / English target summary**

Install CANN Toolkit and configure set_env.sh / environment variables

## K · 容器 / 镜像搭建（环境类，版本敏感 中） / Container setup

共同开发意图：用官方镜像跑一个带加速卡的容器

**CUDA · 完整中文问句 / Complete Chinese question**

怎么用 nvidia-docker / NGC 镜像跑一个带 GPU 的 PyTorch 容器？要装 nvidia-container-toolkit、加 `--gpus` 吗？

**英文目标摘要 / English target summary**

Run a GPU PyTorch container using NVIDIA container tooling

**CANN · 完整中文问句 / Complete Chinese question**

怎么用昇腾官方镜像 / Ascend docker 跑一个带 NPU 的 PyTorch 容器？要挂哪些 `/dev` 设备、用 ascend-docker-runtime 吗？

**英文目标摘要 / English target summary**

Run an NPU PyTorch container using Ascend Docker Runtime

## L · 算子精度排查（调试类，版本敏感 中） / Operator numerical-accuracy diagnosis

共同开发意图：自定义算子结果和参考不一致，怎么逐层/逐元素比对定位

**CUDA · 完整中文问句 / Complete Chinese question**

我的自定义 CUDA 算子结果和 CPU/PyTorch 参考不一致，怎么定位数值精度问题（逐层/逐元素比对）？

**英文目标摘要 / English target summary**

Compare a custom CUDA operator with CPU / PyTorch reference output

**CANN · 完整中文问句 / Complete Chinese question**

我的昇腾算子输出和标杆不一致，怎么用昇腾精度比对工具（msaccucmp / 精度比对 / dump）定位？

**英文目标摘要 / English target summary**

Compare an Ascend operator with reference output using accuracy-comparison tools

## M · 动态 shape / Tiling（算子开发类，版本敏感 高） / Dynamic shapes and tiling

共同开发意图：算子/推理怎么支持动态 shape 输入

**CUDA · 完整中文问句 / Complete Chinese question**

TensorRT/CUDA kernel 处理动态 shape 输入怎么做（optimization profile / 运行时 shape）？

**英文目标摘要 / English target summary**

Handle dynamic shapes in TensorRT / CUDA kernels

**CANN · 完整中文问句 / Complete Chinese question**

Ascend C 自定义算子做动态 shape，Tiling 怎么写、TilingData 怎么定义和传递？

**英文目标摘要 / English target summary**

Define and pass TilingData for a dynamic-shape Ascend C operator

## N · 算子融合（算子开发/性能类，版本敏感 中） / Operator fusion

共同开发意图：算子融合怎么发生、怎么观察和控制

**CUDA · 完整中文问句 / Complete Chinese question**

TensorRT/CUDA 里算子融合（layer/kernel fusion）怎么发生、怎么观察和控制？

**英文目标摘要 / English target summary**

Observe and control TensorRT / CUDA layer or kernel fusion

**CANN · 完整中文问句 / Complete Chinese question**

昇腾 GE 图编译里算子融合规则怎么看、怎么自定义融合 pass（UB 融合/图融合）？

**英文目标摘要 / English target summary**

Inspect and customize Ascend GE / UB fusion rules

## O · 注册与框架集成（算子开发/迁移类，版本敏感 中） / Operator registration and framework integration

共同开发意图：自定义算子怎么注册进框架让它能被调用

**CUDA · 完整中文问句 / Complete Chinese question**

我写了个自定义算子，怎么注册进 PyTorch 让 `torch.ops` 能调（TORCH_LIBRARY / dispatcher / autograd 注册）？

**英文目标摘要 / English target summary**

Register an operator in PyTorch using TORCH_LIBRARY / dispatcher / autograd

**CANN · 完整中文问句 / Complete Chinese question**

我用 Ascend C 写了算子，怎么注册成 aclnn 接口并集成进 torch_npu / PyTorch 让框架能调？

**英文目标摘要 / English target summary**

Register an Ascend C operator as an aclnn interface and integrate it into torch_npu

## P · 混合精度训练（训练类，版本敏感 中） / Mixed-precision training

共同开发意图：训练怎么开混合精度（AMP / loss scale）

**CUDA · 完整中文问句 / Complete Chinese question**

PyTorch 训练怎么开混合精度（AMP）？`torch.cuda.amp.autocast` / GradScaler 怎么用？

**英文目标摘要 / English target summary**

Configure PyTorch AMP / autocast / GradScaler

**CANN · 完整中文问句 / Complete Chinese question**

昇腾上 PyTorch 训练怎么开混合精度？用 torch_npu 的 amp / apex，loss scale 怎么配？

**英文目标摘要 / English target summary**

Configure torch_npu AMP / apex and loss scaling

## Q · 显存 / OOM 优化（训练/性能类，版本敏感 中） / Out-of-memory optimization

共同开发意图：训练报 OOM，怎么排查并优化显存

**CUDA · 完整中文问句 / Complete Chinese question**

PyTorch 训练报 CUDA out of memory，怎么排查和优化显存（max_split_size_mb / 梯度检查点 / empty_cache）？

**英文目标摘要 / English target summary**

Diagnose and reduce CUDA training memory use

**CANN · 完整中文问句 / Complete Chinese question**

昇腾训练报 NPU out of memory，怎么排查和优化显存（PYTORCH_NPU_ALLOC_CONF / 梯度检查点 / 显存碎片）？

**英文目标摘要 / English target summary**

Diagnose and reduce NPU training memory use

## R · 精度 / 收敛排查（调试/训练类，版本敏感 中） / Accuracy and convergence diagnosis

共同开发意图：loss 不收敛 / 对不齐，怎么系统排查

**CUDA · 完整中文问句 / Complete Chinese question**

我的模型在 GPU 上训练 loss 不收敛 / 出现 NaN，怎么系统排查（梯度爆炸/学习率/数据）？

**英文目标摘要 / English target summary**

Diagnose GPU training non-convergence / NaNs

**CANN · 完整中文问句 / Complete Chinese question**

我的模型迁到昇腾 NPU 后 loss 不收敛 / 精度对不齐 GPU，怎么排查（loss scale / 溢出检测 / 算子精度）？

**英文目标摘要 / English target summary**

Diagnose non-convergence or accuracy differences after migration to Ascend

## S · 推理服务部署（推理部署类，版本敏感 中） / Inference service deployment

共同开发意图：把模型部署成在线推理服务

**CUDA · 完整中文问句 / Complete Chinese question**

怎么把模型部署成推理服务？用 Triton Inference Server / TensorRT，怎么配 model repository 和起服务？

**英文目标摘要 / English target summary**

Configure and start Triton / TensorRT inference serving

**CANN · 完整中文问句 / Complete Chinese question**

怎么把模型在昇腾上部署成推理服务？用 MindIE / 昇腾推理服务，怎么配和起服务？

**英文目标摘要 / English target summary**

Configure and start MindIE / Ascend inference serving

## T · 动态 batch / shape 推理（推理部署类，版本敏感 高） / Dynamic-batch and dynamic-shape inference

共同开发意图：部署时怎么配动态 batch / shape 推理

**CUDA · 完整中文问句 / Complete Chinese question**

我用 TensorRT/Triton 部署模型，怎么配置动态 batch / 动态 shape 推理（optimization profile / dynamic batching / min-opt-max shape）？

**英文目标摘要 / English target summary**

Configure TensorRT / Triton optimization profiles and dynamic batching

**CANN · 完整中文问句 / Complete Chinese question**

我用昇腾 MindIE/ACL/ATC 部署模型，怎么配置动态 batch / 动态 shape 推理（dynamic_dims / 分档 / 动态分辨率）？

**英文目标摘要 / English target summary**

Configure MindIE / ACL / ATC dynamic dimensions and batching

## U · 访存 / occupancy 优化（性能优化类，版本敏感 低） / Memory-access and occupancy optimization

共同开发意图：访存受限、利用率低，怎么分析并调优

**CUDA · 完整中文问句 / Complete Chinese question**

我的 kernel occupancy 低、访存受限，怎么用 Nsight Compute 分析并优化（memory coalescing / shared memory / occupancy calculator / bank conflict）？

**英文目标摘要 / English target summary**

Use Nsight Compute to diagnose occupancy and memory bottlenecks

**CANN · 完整中文问句 / Complete Chinese question**

我的昇腾算子访存是瓶颈、AI Core 利用率低，怎么分析并优化（UB/L1 数据搬运、Cube/Vector 利用率、double buffer）？

**英文目标摘要 / English target summary**

Optimize AI Core utilization and UB / L1 transfers / double buffering

## V · 计算与传输重叠（性能优化类，版本敏感 低） / Overlapping computation and transfers

共同开发意图：让数据传输与计算重叠起来

**CUDA · 完整中文问句 / Complete Chinese question**

我想用 CUDA streams + 异步内存拷贝（`cudaMemcpyAsync`）让 H2D/D2H 数据传输与 kernel 计算重叠，怎么做（stream / event / pinned memory）？

**英文目标摘要 / English target summary**

Overlap transfers and CUDA kernels with streams / events / asynchronous copies

**CANN · 完整中文问句 / Complete Chinese question**

我想在昇腾上让数据传输与计算重叠，怎么做（多 stream / 异步内存拷贝 `aclrtMemcpyAsync` / event 同步）？

**英文目标摘要 / English target summary**

Overlap transfers and Ascend computation with streams / events / aclrtMemcpyAsync

## W · 多卡通信优化（性能优化类，版本敏感 中） / Multi-device communication optimization

共同开发意图：多卡 all-reduce 通信慢，怎么调优

**CUDA · 完整中文问句 / Complete Chinese question**

我的多卡 NCCL all-reduce 通信慢，怎么调优（NCCL_ALGO/NCCL_PROTO/拓扑感知/NVLink/NCCL_DEBUG 诊断）？

**英文目标摘要 / English target summary**

Tune NCCL all-reduce communication

**CANN · 完整中文问句 / Complete Chinese question**

我的多卡 HCCL all-reduce 通信慢，怎么调优（HCCL 拓扑/RoCE 网络/HCCL_ALGO/hccn_tool 诊断）？

**英文目标摘要 / English target summary**

Tune HCCL all-reduce communication

## X · 内存越界定位（调试类，版本敏感 中） / Out-of-bounds memory diagnosis

共同开发意图：kernel/算子内存越界，怎么用工具定位是哪一行

**CUDA · 完整中文问句 / Complete Chinese question**

我的 CUDA kernel 报 illegal memory access / 内存越界，怎么用 compute-sanitizer（旧 cuda-memcheck）定位是哪一行越界？

**英文目标摘要 / English target summary**

Locate illegal memory accesses with Compute Sanitizer

**CANN · 完整中文问句 / Complete Chinese question**

我的昇腾算子内存越界 / 踩内存，怎么用昇腾工具（msSanitizer / mem check / 算子内存检测）定位？

**英文目标摘要 / English target summary**

Locate Ascend operator memory errors with msSanitizer

## Y · 跨芯片迁移（迁移类，版本敏感 高） / Migration across chip generations

共同开发意图：模型从一代/一款芯片迁到另一款要注意什么

**CUDA · 完整中文问句 / Complete Chinese question**

我的模型/代码从一代 NVIDIA GPU 迁到另一代（如 Volta→Hopper、不同 compute capability），要注意什么（重编译 `-arch/sm_xx`、PTX 兼容、TensorRT engine 不跨架构复用）？

**英文目标摘要 / English target summary**

Migrate across NVIDIA GPU generations / compute capabilities

**CANN · 完整中文问句 / Complete Chinese question**

我的模型从一款昇腾芯片迁到另一款（如 310→910 或不同昇腾型号），要注意什么（soc_version 重新 ATC 转 .om、算子支持差异、精度/性能重测）？

**英文目标摘要 / English target summary**

Migrate across Ascend chip models / soc_version settings

## Z · 概念心智模型对照（迁移类，版本敏感 低） / Programming-model concepts

共同开发意图：讲清编程模型核心概念怎么映射到硬件

**CUDA · 完整中文问句 / Complete Chinese question**

请讲清 CUDA 编程模型的核心概念（grid / block / thread / warp / SM / global·shared·register memory），它们怎么映射到硬件？

**英文目标摘要 / English target summary**

Explain CUDA grid / block / warp / SM and memory hierarchy

**CANN · 完整中文问句 / Complete Chinese question**

请讲清昇腾 AI Core 编程模型的核心概念（AI Core / Cube / Vector / Scalar 单元、UB·L1·GM 存储层级），并与 CUDA 的 grid/block/thread/SM/shared-mem 概念怎么对应？

**英文目标摘要 / English target summary**

Explain Ascend AI Core units and memory hierarchy in relation to CUDA
