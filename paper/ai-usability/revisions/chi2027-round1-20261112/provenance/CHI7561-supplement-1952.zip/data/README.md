# Task data and calculation appendix

This directory provides the task data, source evidence, assessment protocol, and calculations for the paper. Packaging these materials does not add retrieval runs or hardware-execution trials.

Run with Python 3.9 or later, without third-party dependencies:

```sh
python3 scripts/build_paper_analysis.py
```

Run the command from the paper directory, or invoke the script by its location from any working directory. To move this appendix, keep `data/` beside `scripts/build_paper_analysis.py`. The script verifies frozen-file hashes, checks that the frozen RAW and scores exactly match the packaged original scoring script, and writes deterministic outputs under `data/generated/`. It does not require the original project, network access, or local absolute paths.

## Frozen inputs

| File | Contents |
| --- | --- |
| `manifest.json` | Source identities, SHA-256 hashes, freeze date, and included-file hashes. |
| `legacy_score_metrics.py` | Byte-for-byte copy of the original scoring script; retained for reproduction, not recommended as a validated instrument. |
| `legacy_task_run_log.md` | Byte-for-byte copy of the compiled task-run summary. This is not an original tool transcript. |
| `raw_original.json` | All 26 × 2 original RAW records, including judgment-based fields and unknown dates. |
| `legacy_scores_original.json` | All 52 original score rows and formula outputs. |
| `tasks.json` | Complete task list, retained Chinese questions, editorial English target summaries, original workflow groups, and paper-scope flags. |
| `source_evidence.json` | Frozen excerpts and original line references supporting the audit decisions and task taxonomy. |
| `corrections.json` | Explicit scope, source-ownership, unresolved-count, and interpretation decisions. |

## Readable question pairs

`task-question-pairs-cn-en.md` presents all 26 task pairs with shared development intents, complete Chinese questions reproduced from `tasks.json`, and English target summaries. G is identified separately as a ROCm/HIP migration analogy. The main paper presents condensed examples J, I, and X.

## Generated outputs

`generated/paper_analysis.json` contains 25-pair descriptive statistics, separately labelled 26-pair full-sample statistics, workflow summaries, and an arithmetic removal of the model-prior channel. It records both means of exact formula results and means of the original three-decimal results, avoiding silent rounding differences.

`generated/units.json` retains all 52 units with their original RAW and original scores, descriptive content-acquisition status, an explicitly unknown access route when the data do not preserve one, known source-ownership exclusion, unresolved issues, and arithmetic sensitivity result. `generated/task_table.md`, `generated/corrections.md`, and `generated/english_findings.md` are readable paper appendices. `worked-recording-example-a-cann.json` shows how a future record links requirements, events, sources, saved evidence, and codes without altering frozen data.

`supplementary-analysis-notes-cn-en.md` explains the 25-pair and 26-row composite summaries, formula sensitivity, scoring codes, documented discrepancies, and interpretation of proposed improvements in English and Chinese.

## Data preservation and analysis adjustments

`design-illustrations-cn-en.md` identifies the observed task conditions and proposed interactions in Figures 10-15. The supplement includes the twelve editable bilingual SVGs in `figures/`; these illustrations do not add task observations or change the frozen data.

- G is a migration analogy whose CUDA-labelled side examines AMD ROCm/HIP. It remains in the dataset but is excluded from the 25-pair primary description.
- H.cuda's `nvidia-blog` entry is treated as vendor-owned official material in the audit view. It is removed from the count of candidate secondary sources in that view. Original RAW and original scores are not overwritten or presented as corrected scores.
- A.cann's zero failed-fetch count conflicts with a missing-body report in the retained log. It remains unresolved; no replacement value is invented.
- `static` and `ssr` map to the same descriptive content-acquisition status. `partial` and `spa`/`robots` remain distinct. The `core_fetch` field does not consistently preserve whether an entry was original or alternative, so no access route is inferred from it. This mapping does not infer sufficiency or execution success. The matrix and composite use the published M2 scores: robots=1, spa=2, partial=3, ssr=4, static=5. This descriptive grouping does not replace the numeric scoring rules.
- Removing the prior channel sets `OWN=0` inside the original formula while leaving all other inputs unchanged. It is an assumption-sensitivity calculation, not a run of a different model or a no-retrieval condition.

## Data interpretation

`raw_original` fields and their scoring anchors are documented in the packaged scoring script. `own`, `consist`, `churn`, `ref_level`, `pin`, and `repro` include judgment or coding decisions. In particular, `repro=copyrun` is a task assessment, not evidence that code was run successfully. The legacy index is not a calibrated probability.

The field `candidate_secondary_count_after_known_ownership_exclusion` applies only the explicitly documented H.cuda ownership correction. It must not be read as a verified count of independent, accessible, or answer-supporting sources. `independent_source_count_verified` remains `null` for every unit. Original questions for later batches are labelled according to what the compiled log reports about their recovery; original transcripts have not been reconstructed or added.

No retained aggregate should be interpreted as a current website measurement, ecosystem ranking, causal effect, developer success rate, or validated model capability estimate.

## Current M2 anchors

`m2_scoring.json` specifies robots=1, spa=2, partial=3, ssr=4, static=5 and the C.cann/Y.cann record checks. `scripts/build_paper_analysis.py` applies these anchors to the retained observations, recalculates M11 and sensitivity summaries, and writes `generated/current_scores.json`, which the paper figure builder reads. Original inputs and their hashes remain intact for provenance.

## Selected web_fetch evidence

`selected-webfetch-evidence-cn-en.md` provides selected requests and tool-return excerpts for A’s conversion quickstart, D’s operator-development entry, and E’s EZ9999 error entry, including URLs, timestamps, and interpretation boundaries. These are tool-delivered excerpts, not raw webpage captures or a complete set of developer-facing answers.
